using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Tripolygon.UModelerX.PureCode.SourceControl
{
    public enum UMXRelatedFileRole
    {
        Container,
        Reference,
        Alias,
        Generated
    }

    public sealed class UMXRelatedFileEntry
    {
        public UMXRelatedFileEntry(UMXRelatedFileRole role, string path)
        {
            Role = role;
            Path = UMXRelatedFileManifest.NormalizePath(path);
        }

        public UMXRelatedFileRole Role { get; }
        public string Path { get; }
    }

    public sealed class UMXRelatedFileGroup
    {
        readonly Dictionary<string, UMXRelatedFileEntry> entries =
            new Dictionary<string, UMXRelatedFileEntry>(StringComparer.Ordinal);

        public UMXRelatedFileGroup(string id)
        {
            Id = string.IsNullOrEmpty(id) == false
                ? id
                : throw new ArgumentException("그룹 ID가 비어 있습니다.", nameof(id));
        }

        public string Id { get; }
        public IReadOnlyCollection<UMXRelatedFileEntry> Entries => entries.Values;

        public void Add(string path, UMXRelatedFileRole role)
        {
            path = UMXRelatedFileManifest.NormalizePath(path);
            if (UMXRelatedFileManifest.IsValidPath(path) == false)
            {
                return;
            }

            if (entries.TryGetValue(path, out var existing) == true)
            {
                if (RolePriority(role) > RolePriority(existing.Role))
                {
                    entries[path] = new UMXRelatedFileEntry(role, path);
                }
                return;
            }
            entries.Add(path, new UMXRelatedFileEntry(role, path));
        }

        public bool ContainsRole(UMXRelatedFileRole role)
        {
            return entries.Values.Any(entry => entry.Role == role);
        }

        public void RemoveRole(UMXRelatedFileRole role)
        {
            var paths = entries.Where(pair => pair.Value.Role == role).Select(pair => pair.Key).ToArray();
            foreach (var path in paths)
            {
                entries.Remove(path);
            }
        }

        static int RolePriority(UMXRelatedFileRole role)
        {
            return role == UMXRelatedFileRole.Generated ? 2 :
                role == UMXRelatedFileRole.Container ? 1 : 0;
        }
    }

    public sealed class UMXRelatedFileManifest
    {
        public const string Header = "# UModeler related files manifest v2";

        readonly Dictionary<string, UMXRelatedFileGroup> groups =
            new Dictionary<string, UMXRelatedFileGroup>(StringComparer.Ordinal);

        public IReadOnlyCollection<UMXRelatedFileGroup> Groups => groups.Values;

        public void SetGroup(UMXRelatedFileGroup group)
        {
            if (group == null)
            {
                throw new ArgumentNullException(nameof(group));
            }
            groups[group.Id] = group;
        }

        public UMXRelatedFileGroup GetOrCreateGroup(string id)
        {
            if (groups.TryGetValue(id, out var group) == false)
            {
                group = new UMXRelatedFileGroup(id);
                groups.Add(id, group);
            }
            return group;
        }

        public void RemoveGroupsContaining(string path, UMXRelatedFileRole role)
        {
            path = NormalizePath(path);
            var ids = groups.Values
                .Where(group => group.Entries.Any(entry => entry.Role == role && entry.Path == path))
                .Select(group => group.Id)
                .ToArray();
            foreach (var id in ids)
            {
                groups.Remove(id);
            }
        }

        public bool ContainsContainer(string path)
        {
            path = NormalizeSelectedPath(path);
            return groups.Values.Any(group =>
                group.Entries.Any(entry => entry.Role == UMXRelatedFileRole.Container && entry.Path == path));
        }

        public string Serialize()
        {
            var builder = new StringBuilder().AppendLine(Header);
            foreach (var group in groups.Values.OrderBy(item => item.Id, StringComparer.Ordinal))
            {
                foreach (var entry in group.Entries.OrderBy(item => item.Path, StringComparer.Ordinal))
                {
                    builder.Append(group.Id).Append('\t').Append(RoleToken(entry.Role))
                        .Append('\t').Append(entry.Path).Append('\n');
                }
            }
            return builder.ToString();
        }

        public static bool TryParse(string text, out UMXRelatedFileManifest manifest, out string error)
        {
            manifest = new UMXRelatedFileManifest();
            error = null;
            if (text == null)
            {
                error = "매니페스트 내용이 없습니다.";
                return false;
            }

            using (var reader = new StringReader(text))
            {
                if (reader.ReadLine() != Header)
                {
                    error = "지원하지 않는 매니페스트 버전입니다.";
                    return false;
                }

                string line;
                var lineNumber = 1;
                while ((line = reader.ReadLine()) != null)
                {
                    lineNumber++;
                    if (string.IsNullOrWhiteSpace(line) == true || line[0] == '#')
                    {
                        continue;
                    }

                    var columns = line.Split('\t');
                    if (columns.Length != 3 || string.IsNullOrEmpty(columns[0]) == true ||
                        TryParseRole(columns[1], out var role) == false || IsValidPath(columns[2]) == false)
                    {
                        error = $"{lineNumber}번째 줄의 형식이 올바르지 않습니다.";
                        manifest = new UMXRelatedFileManifest();
                        return false;
                    }
                    manifest.GetOrCreateGroup(columns[0]).Add(columns[2], role);
                }
            }
            return true;
        }

        public static string NormalizePath(string path)
        {
            return string.IsNullOrEmpty(path) == true ? string.Empty : path.Replace('\\', '/');
        }

        public static string NormalizeSelectedPath(string path)
        {
            path = NormalizePath(path);
            return path.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)
                ? path.Substring(0, path.Length - 5)
                : path;
        }

        public static bool IsValidPath(string path)
        {
            return string.IsNullOrEmpty(path) == false &&
                   path.IndexOf('\t') < 0 && path.IndexOf('\r') < 0 && path.IndexOf('\n') < 0;
        }

        static string RoleToken(UMXRelatedFileRole role)
        {
            switch (role)
            {
                case UMXRelatedFileRole.Container: return "container";
                case UMXRelatedFileRole.Reference: return "reference";
                case UMXRelatedFileRole.Alias: return "alias";
                case UMXRelatedFileRole.Generated: return "generated";
                default: throw new ArgumentOutOfRangeException(nameof(role), role, null);
            }
        }

        static bool TryParseRole(string token, out UMXRelatedFileRole role)
        {
            switch (token)
            {
                case "container": role = UMXRelatedFileRole.Container; return true;
                case "reference": role = UMXRelatedFileRole.Reference; return true;
                case "alias": role = UMXRelatedFileRole.Alias; return true;
                case "generated": role = UMXRelatedFileRole.Generated; return true;
                default: role = default; return false;
            }
        }
    }

    public static class UMXRelatedFileResolver
    {
        public static IReadOnlyList<UMXRelatedFileEntry> Resolve(
            UMXRelatedFileManifest manifest,
            IEnumerable<string> selectedPaths)
        {
            if (manifest == null || selectedPaths == null)
            {
                throw new ArgumentNullException(manifest == null ? nameof(manifest) : nameof(selectedPaths));
            }

            var groupsByPath = new Dictionary<string, List<UMXRelatedFileGroup>>(StringComparer.Ordinal);
            foreach (var group in manifest.Groups)
            {
                foreach (var entry in group.Entries)
                {
                    if (groupsByPath.TryGetValue(entry.Path, out var relatedGroups) == false)
                    {
                        relatedGroups = new List<UMXRelatedFileGroup>();
                        groupsByPath.Add(entry.Path, relatedGroups);
                    }
                    relatedGroups.Add(group);
                }
            }

            var pending = new Queue<string>(selectedPaths.Select(UMXRelatedFileManifest.NormalizeSelectedPath));
            var visitedPaths = new HashSet<string>(StringComparer.Ordinal);
            var visitedGroups = new HashSet<string>(StringComparer.Ordinal);
            var resolved = new Dictionary<string, UMXRelatedFileEntry>(StringComparer.Ordinal);

            while (pending.Count > 0)
            {
                var path = pending.Dequeue();
                if (visitedPaths.Add(path) == false ||
                    groupsByPath.TryGetValue(path, out var relatedGroups) == false)
                {
                    continue;
                }

                foreach (var group in relatedGroups)
                {
                    if (visitedGroups.Add(group.Id) == false)
                    {
                        continue;
                    }

                    foreach (var entry in group.Entries)
                    {
                        if (resolved.TryGetValue(entry.Path, out var existing) == false ||
                            entry.Role == UMXRelatedFileRole.Generated &&
                            existing.Role != UMXRelatedFileRole.Generated)
                        {
                            resolved[entry.Path] = entry;
                        }
                        pending.Enqueue(entry.Path);
                    }
                }
            }
            return resolved.Values.OrderBy(entry => entry.Path, StringComparer.Ordinal).ToArray();
        }
    }
}
