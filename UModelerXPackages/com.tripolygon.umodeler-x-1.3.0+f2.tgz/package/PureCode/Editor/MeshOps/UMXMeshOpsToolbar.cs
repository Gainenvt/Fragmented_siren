﻿#if UNITY_2021_2_OR_NEWER
using UnityEngine;
using UnityEditor;
using Tripolygon.UModelerX.Editor.MeshOpsProcessor;
using Tripolygon.UModelerX.Editor.Views.Toolbar;

namespace Tripolygon.UModelerX.Editor.MeshOps
{
    using UnityEditor.Overlays;

#if UNITY_6000_1_OR_NEWER // 2023 ~ 6
    // defaultDockIndex 로 상단 툴바 안에서의 기본 순서를 고정한다 (UMX Settings=0 / UMX Object=1 / UMX Mesh Ops=2).
    // 이미 오버레이 배치를 저장해 둔 사용자는 그 레이아웃이 우선하므로, 순서를 보려면 씬뷰 오버레이 메뉴에서 레이아웃을 초기화해야 한다.
    [Overlay(typeof(SceneView), "UMX Mesh Ops", true, defaultLayout = Layout.HorizontalToolbar, defaultDockZone = DockZone.TopToolbar, defaultDockIndex = 2, priority = 220)]
#elif UNITY_2022_3_OR_NEWER // 2021_2 ~ 2021_3
    [Overlay(typeof(SceneView), "UMX Mesh Ops", true, defaultLayout = Layout.HorizontalToolbar, defaultDockZone = DockZone.TopToolbar, defaultDockIndex = 2)]
#endif
    [Icon("Assets/Unity-UModelerX/Editor/Resources/Tripolygon/UModelerX/Editor/Views/Toolbar/UMXMeshOpsToolbar.png")]
    public class UMXMeshOpsToolbar : ToolbarOverlay
    {
        //UMX Toolbar 추가 시 생성자 목록에도 같이 추가되어야함.동일한 string.
        public UMXMeshOpsToolbar() : base("SceneView/UMX UModelerize", "SceneView/UMX Combine", "SceneView/UMX Split Parts",
            "SceneView/UMX Pivot", "SceneView/UMX Reset X Form")
        {
            UMXOverlayBootstrap.SignedInEvent += UMXOverlayBootstrap_SignedInEvent;
        }

#if UNITY_2022_3_OR_NEWER
        public override void OnCreated()
        {
            // [Icon] 은 에셋 경로 고정이라 테마를 못 가린다. TextureProvider 가 @Light 폴더를 태운다.
            // 타입명 경로에 해당하는 리소스가 없으면 TextureProvider 가 Tripolygon/None(빨간 금지 아이콘)으로 폴백해 [Icon] 을 덮어쓴다.
            // 이 오버레이 전용 아이콘이므로 실존 경로를 직접 지정한다.
            this.collapsedIcon = TextureProvider.Load("Tripolygon/UModelerX/Editor/Views/Toolbar/UMXMeshOpsToolbar");
        }
#endif

        private void UMXOverlayBootstrap_SignedInEvent(object sender, System.EventArgs e)
        {
            EditorApplication.delayCall += () =>
            {
                this.displayed = this.displayed && UMXOverlayBootstrap.ConfigureVisibility();
            };
        }
    }
    // 2021.1 이하 버전은 일단 지원하지 않는 것으로 합니다.
}
#endif
