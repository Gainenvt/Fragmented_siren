#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor.Toolbars;
using UnityEngine;
using UnityEngine.UIElements;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    /// UMX Object 컨트롤 8종을 만들어 (종류 → VisualElement) 로 돌려주는 팩토리.
    /// 유니티 오버레이 호스트와 씬 배치 호스트가 공용한다.
    /// VisualElement 는 부모를 하나만 가지므로 활성 호스트만 Build() 를 호출해야 한다.
    public static class UMXObjectControlSet
    {
        /// 버튼 배치 순서(스펙 §1에서 Soft▾ 제외): [V][E] │ [Display▾][Select] │ [Coord▾][V-Snap▾] │ [Anim][Sym]
        /// 소프트 셀렉션은 오버레이에서 빼고 엘레멘트 툴 옵션 패널로 되돌렸다.
        /// Dictionary 의 열거 순서는 언어 사양상 보장되지 않으므로(M3) List 로 순서를 명시적으로 고정한다.
        public static List<(UMXOverlayControls Control, VisualElement Element)> Build()
        {
            return new List<(UMXOverlayControls, VisualElement)>
            {
                (UMXOverlayControls.VertexToggle, new UMXElementOverlayToggle(isVertex: true)),
                (UMXOverlayControls.EdgeToggle, new UMXElementOverlayToggle(isVertex: false)),
                (UMXOverlayControls.DisplayDropdown, new UMXDisplayModeSplitButton()),
                (UMXOverlayControls.SelectDropdown, new UMXSelectOptionToggleGroup()),
                (UMXOverlayControls.CoordinateSystem, new UMXCoordinateSystemSettingToolbarButton()),
                (UMXOverlayControls.ElementSnap, new UMXElementSnapSettingToolbarButton()),
                (UMXOverlayControls.ApplyAnimation, new UMXApplyAnimationToolbarToggle()),

                // Symmetry 는 기능 미구현이라 자리만 잡아 둔다.
                // UMXOverlayContext 가 항상 숨기므로 렌더되지 않는다.
                (UMXOverlayControls.Symmetry, new EditorToolbarToggle { tooltip = "Symmetry editing" }),
            };
        }

        private const string StyleSheetPath = "Tripolygon/UModelerX/Editor/Views/Toolbar/UMXObjectOverlay";

        // 기동 직후 로드 실패 시 다시 시도하는 횟수. 임포트가 끝나기까지 몇 틱이면 충분하고,
        // 스타일시트가 정말 없는 경우 무한히 도는 것을 막는다.
        private const int StyleSheetRetryCount = 30;

        /// <summary>
        /// 스타일시트를 컨테이너에 붙인다.
        /// 에디터 기동 직후에는 임포트가 끝나기 전이라 Resources.Load 가 null 을 돌려줄 수 있는데,
        /// 그대로 두면 크기 규칙이 통째로 빠져 아이콘이 텍스처 원본 크기로 렌더된다.
        /// HiDPI 에서는 TextureProvider 가 @2x 를 주므로 그때 두 배로 커져 보인다. 그래서 준비될 때까지 다시 시도한다.
        /// </summary>
        public static void AttachStyleSheet(VisualElement container)
        {
            if (container == null)
            {
                return;
            }
            if (TryAttachStyleSheet(container))
            {
                return;
            }

            RetryAttachStyleSheet(container, StyleSheetRetryCount);
        }

        private static bool TryAttachStyleSheet(VisualElement container)
        {
            var styleSheet = Resources.Load<StyleSheet>(StyleSheetPath);
            if (styleSheet == null)
            {
                return false;
            }
            if (container.styleSheets.Contains(styleSheet) == false)
            {
                container.styleSheets.Add(styleSheet);
            }
            return true;
        }

        private static void RetryAttachStyleSheet(VisualElement container, int remaining)
        {
            if (remaining <= 0)
            {
#if !FINAL
                global::Tripolygon.UModelerX.Runtime.UMXLog.Warning(
                    $"[UMXObjectControlSet] StyleSheet '{StyleSheetPath}' not found. Toolbar icons fall back to their texture size.",
                    "Editor");
#endif
                return;
            }

            void Retry()
            {
                UnityEditor.EditorApplication.delayCall -= Retry;
                if (TryAttachStyleSheet(container))
                {
                    return;
                }
                RetryAttachStyleSheet(container, remaining - 1);
            }

            UnityEditor.EditorApplication.delayCall += Retry;
        }

        /// 현재 컨텍스트에 맞춰 자식 표시를 갱신한다.
        public static void ApplyVisibility(List<(UMXOverlayControls Control, VisualElement Element)> controls)
        {
            if (controls == null)
            {
                return;
            }

            foreach (var pair in controls)
            {
                bool visible = UMXOverlayContext.IsVisible(pair.Control);

                // 동적 상태라 USS 클래스로는 표현할 수 없어 style.display 를 직접 설정한다.
                pair.Element.style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
            }
        }
    }
}
#endif
