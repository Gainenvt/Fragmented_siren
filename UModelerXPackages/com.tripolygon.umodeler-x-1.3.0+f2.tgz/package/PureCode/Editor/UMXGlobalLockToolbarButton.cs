#if UNITY_EDITOR
using UnityEditor;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
#if UNITY_2021_2_OR_NEWER
    using UnityEditor.Toolbars;
    using UnityEngine;
    using UnityEngine.UIElements;

    /// <summary>SceneView 상단 툴바의 전역 잠금 토글 버튼.</summary>
    [EditorToolbarElement("SceneView/UMX Global Lock")]
    public class UMXGlobalLockToolbarButton : EditorToolbarToggle
    {
        public UMXGlobalLockToolbarButton()
        {
            this.tooltip = "Lock / Unlock all UModelerX objects";

            // 아이콘은 생성자에서 읽지 않는다. 유니티가 오버레이 배치를 복원하며 이 엘레멘트를 만드는 시점에는
            // Resources 조회가 실패해 아이콘이 빈 상태로 굳는다. 같은 툴바의 다른 버튼들과 동일하게 한 틱 미룬다.
            EditorApplication.update += Init;

            this.SetValueWithoutNotify(UMXLockState.IsGlobalLocked);
            this.RegisterValueChangedCallback(evt => UMXLockState.SetGlobalLocked(evt.newValue));

            // 다른 진입점(메뉴 등)으로 상태가 바뀌면 버튼도 동기화.
            UMXLockState.LockChanged += SyncFromState;
            this.RegisterCallback<DetachFromPanelEvent>(_ => UMXLockState.LockChanged -= SyncFromState);
        }

        private void Init()
        {
            EditorApplication.update -= Init;

            // UModelerX 자체 아이콘 사용. on=Lock(닫힌 자물쇠), off=Unlock(열린 자물쇠).
            // TextureProvider 를 태워 @2x·@Light 테마 폴더까지 따라가게 한다(원시 Resources.Load 는 둘 다 놓친다).
            this.onIcon = TextureProvider.Load("Tripolygon/UModelerX/Editor/Views/Inspector/SourceMeshItemView/Lock");
            this.offIcon = TextureProvider.Load("Tripolygon/UModelerX/Editor/Views/Inspector/SourceMeshItemView/Unlock");

            // 아이콘 교체를 화면에 반영시킨다. 토글은 현재 값에 맞는 쪽 아이콘만 그린다.
            this.SetValueWithoutNotify(UMXLockState.IsGlobalLocked);
        }

        private void SyncFromState()
        {
            this.SetValueWithoutNotify(UMXLockState.IsGlobalLocked);
        }
    }
#endif
}
#endif
