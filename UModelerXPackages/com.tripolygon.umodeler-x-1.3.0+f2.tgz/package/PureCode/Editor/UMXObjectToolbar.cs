#if UNITY_EDITOR
#if UNITY_2021_2_OR_NEWER
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Overlays;
using UnityEngine;
using UnityEngine.UIElements;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
#if UNITY_6000_1_OR_NEWER // 2023 ~ 6
    [Overlay(typeof(SceneView), "UMX Object", true, defaultLayout = Layout.HorizontalToolbar, defaultDockZone = DockZone.TopToolbar, defaultDockIndex = 1, priority = 210)]
#elif UNITY_2022_1_OR_NEWER
    // defaultDockIndex 로 상단 툴바 안에서의 기본 순서를 고정한다 (UMX Settings=0 / UMX Object=1 / UMX Mesh Ops=2).
    // 이미 오버레이 배치를 저장해 둔 사용자는 그 레이아웃이 우선하므로, 순서를 보려면 씬뷰 오버레이 메뉴에서 레이아웃을 초기화해야 한다.
    [Overlay(typeof(SceneView), "UMX Object", true, defaultLayout = Layout.HorizontalToolbar, defaultDockZone = DockZone.TopToolbar, defaultDockIndex = 1)]
#else
    [Overlay(typeof(SceneView), "UMX Object", true)]
#endif
    [Icon("Assets/Unity-UModelerX/Editor/Resources/Tripolygon/UModelerX/Editor/Views/Toolbar/UMXObjectToolbar.png")]
    public class UMXObjectToolbar : Overlay, ICreateHorizontalToolbar, ICreateVerticalToolbar
    {
        private List<(UMXOverlayControls Control, VisualElement Element)> controls;

        // 오브젝트가 없을 때 컨트롤 대신 보여 줄 아이콘. Overlay.collapsed 를 쓰면 유니티가 접힌 버튼에
        // 펼침용 캐럿(▾)을 붙이고 클릭도 먹는데, 여기서는 "버튼 이미지만" 이 요구사항이라 접지 않고
        // 툴바 내용만 이 이미지로 바꾼다. pickingMode 를 Ignore 로 두어 눌리지 않게 한다.
        private Image placeholder;

        public override void OnCreated()
        {
            // [Icon] 은 테마를 못 가리므로 라이트/다크 대응 아이콘으로 덮어쓴다.
            // 타입명 경로에 해당하는 리소스가 없으면 TextureProvider 가 Tripolygon/None(빨간 금지 아이콘)으로 폴백해 [Icon] 을 덮어쓴다.
            // 이 오버레이 전용 아이콘이므로 실존 경로를 직접 지정한다.
            this.collapsedIcon = TextureProvider.Load("Tripolygon/UModelerX/Editor/Views/Toolbar/UMXObjectToolbar");

            UMXOverlayContext.Changed += Refresh;

            // 오버레이를 닫아 두면 이관된 프로퍼티(Display/Select 카테고리)에 닿을 경로가 없어지므로,
            // 인스펙터 툴 옵션 패널이 그것들을 다시 그리도록 표시 상태를 알린다.
            // 인스턴스는 씬뷰마다 하나씩이고 표시 여부도 씬뷰별로 저장되므로 생성·파괴까지 등록한다.
            this.displayedChanged += OnDisplayedChanged;
            UMXOverlayContext.RegisterObjectOverlayHost(this, this.displayed);

            // Create*Content 호출 전에도 displayed 상태가 현재 설정을 반영해야 한다.
            Refresh();
        }

        public override void OnWillBeDestroyed()
        {
            UMXOverlayContext.Changed -= Refresh;
            this.displayedChanged -= OnDisplayedChanged;
            UMXOverlayContext.UnregisterObjectOverlayHost(this);

            // displayed 세터를 거치지 않는 유일한 파괴 경로이므로 여기서는 TeardownControls() 가 필수다.
            TeardownControls();
        }

        private void OnDisplayedChanged(bool displayed)
        {
            UMXOverlayContext.SetObjectOverlayDisplayed(this, displayed);
        }

        public OverlayToolbar CreateHorizontalToolbarContent() => BuildToolbar();

        public OverlayToolbar CreateVerticalToolbarContent() => BuildToolbar();

        public override VisualElement CreatePanelContent() => BuildToolbar();

        /// 레이아웃 전환 시마다 다시 호출될 수 있으므로 매번 새로 만들고 캐시를 교체한다.
        private OverlayToolbar BuildToolbar()
        {
            TeardownControls();

            var toolbar = new OverlayToolbar();
            UMXObjectControlSet.AttachStyleSheet(toolbar);

            this.controls = UMXObjectControlSet.Build();
            foreach (var pair in this.controls)
            {
                toolbar.Add(pair.Element);
            }

            UMXObjectControlSet.ApplyVisibility(this.controls);

            // 컨트롤이 하나도 안 보일 때 대신 나올 아이콘. 화살표 없는 순수 이미지이고 입력도 안 받는다.
            this.placeholder = new Image
            {
                image = TextureProvider.Load("Tripolygon/UModelerX/Editor/Views/Toolbar/UMXObjectToolbar"),
                pickingMode = PickingMode.Ignore,
            };
            this.placeholder.AddToClassList("umx-object-toolbar__placeholder");
            toolbar.Add(this.placeholder);

            ApplyPlaceholder();
            return toolbar;
        }

        /// 보일 컨트롤이 하나도 없으면 아이콘만 남긴다. Overlay.collapsed 를 쓰지 않는 이유는
        /// placeholder 필드 주석 참조 — 접으면 유니티가 캐럿 달린 클릭 가능한 버튼을 만든다.
        private void ApplyPlaceholder()
        {
            if (this.placeholder == null)
            {
                return;
            }

            bool showPlaceholder = UMXOverlayContext.HasAnyVisible == false;
            this.placeholder.style.display = showPlaceholder ? DisplayStyle.Flex : DisplayStyle.None;
        }

        /// 만들어 둔 컨트롤을 계층에서 직접 떼어낸다.
        private void TeardownControls()
        {
            if (this.placeholder != null)
            {
                this.placeholder.RemoveFromHierarchy();
                this.placeholder = null;
            }

            if (this.controls == null)
            {
                return;
            }

            foreach (var pair in this.controls)
            {
                pair.Element.RemoveFromHierarchy();
            }

            this.controls = null;
        }



        private void Refresh()
        {
            UMXObjectControlSet.ApplyVisibility(this.controls);
            ApplyPlaceholder();
        }
    }
}
#endif
#endif
