﻿using UnityEditor;
using System;
using System.Reflection;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    using Tripolygon.UModeler.UI;
#if UNITY_2021_2_OR_NEWER
    using UnityEditor.Toolbars;
    using UnityEngine.UIElements;
    [EditorToolbarElement("SceneView/UMX Coordinate System Setting")]
    public class UMXCoordinateSystemSettingToolbarButton : EditorToolbarDropdown
    {
        MethodInfo repaintMethod;

        public UMXCoordinateSystemSettingToolbarButton()
        {
            var toolbarType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.Toolbar");
            repaintMethod = toolbarType.GetMethod("RepaintToolbar", BindingFlags.NonPublic | BindingFlags.Static);
            var dropdown = new UMXCoordinateSystemSettingToolbarDropdown(this);
            this.clicked += UMXCoordinateSystemSettingToolbarDropdown.ShowDropdown;
            Tools.pivotRotationChanged -= OnPivotRotationChanged;
            Tools.pivotRotationChanged += OnPivotRotationChanged;
            // UMXObjectControlSet.Build() 가 오버레이 레이아웃 전환·호스트 전환·씬뷰 마운트마다 반복 호출되어
            // 인스턴스가 계속 생성된다 — 해제하지 않으면 Tools.pivotRotationChanged 구독이 인스턴스 수만큼 누적된다.
            RegisterCallback<DetachFromPanelEvent>(_ => Dispose());
            EditorApplication.update += Init;

        }

        private void Init()
        {
            this.text = Enum.GetName(typeof(UMXCoordinateSystem), CoordinateSystemSetting.CoordinateSystem);
            this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), this.text);
            this.tooltip = "UModelerX Coordinate System";
            EditorApplication.update -= Init;
        }

        public void Dispose()
        {
            Tools.pivotRotationChanged -= OnPivotRotationChanged;
        }
        // UNITY_2021_2_OR_NEWER
#elif UNITY_2020_1_OR_NEWER
    public class UMXCoordinateSystemSettingToolbarButton : ToolbarDropdownButton
    {
        Type toolbarType;
        MethodInfo repaintMethod;
        private PivotRotation editorPivot;

        public UMXCoordinateSystemSettingToolbarButton() : base()
        {
            toolbarType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.Toolbar");
            repaintMethod = toolbarType.GetMethod("RepaintToolbar", BindingFlags.NonPublic | BindingFlags.Static);
            this.text = Enum.GetName(typeof(UMXCoordinateSystem), CoordinateSystemSetting.CoordinateSystem);
            editorPivot = Tools.pivotRotation;
            UMXCoordinateSystemSettingToolbarDropdown dropdown = new UMXCoordinateSystemSettingToolbarDropdown(this);
            onClicked += UMXCoordinateSystemSettingToolbarDropdown.ShowDropdown;
        }

        public override void Render(Rect rect)
        {
            // Tools pivotRotation 변경 확인
            if (editorPivot != Tools.pivotRotation)
            {
                editorPivot = Tools.pivotRotation;
                OnPivotRotationChanged();
            }

            base.Render(rect);
        }
#endif //UNITY_2020_1_OR_NEWER

        // 2020, 2021.2 ~ 6 공유 메소드
        private void OnPivotRotationChanged()
        {
            if (Tools.pivotRotation == PivotRotation.Global)
            {
                CoordinateSystemSetting.CoordinateSystem = UMXCoordinateSystem.Global;
                this.text = nameof(UMXCoordinateSystem.Global);
                this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), nameof(UMXCoordinateSystem.Global));
            }
            else if (Tools.pivotRotation == PivotRotation.Local)
            {
                CoordinateSystemSetting.CoordinateSystem = UMXCoordinateSystem.Local;
                this.text = nameof(UMXCoordinateSystem.Local);
                this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), nameof(UMXCoordinateSystem.Local));
            }
            repaintMethod?.Invoke(null, null);
        }
    }
}
