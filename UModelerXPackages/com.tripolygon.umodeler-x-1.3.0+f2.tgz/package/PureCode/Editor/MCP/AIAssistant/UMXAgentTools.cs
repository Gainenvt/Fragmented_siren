using System;
using System.Linq;
using System.Reflection;
using Tripolygon.UModelerX.Editor.Modelings;
using Tripolygon.UModelerX.Editor.Views;
using Tripolygon.UModelerX.Runtime;
using Unity.AI.Assistant.FunctionCalling;
using UnityEditor;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.MCP.AIAssistant
{
    // Unity AI Assistant 의 Agent 모드에서 호출 가능한 UModelerX 도구.
    // MCP 외부 클라이언트용 [McpTool] 들과는 별도로 Agent 모드 전용 [AgentTool] 어트리뷰트로 노출.
    public static class UMXAgentTools
    {
        [AgentTool("Create a new empty UModelerX editable mesh GameObject using the standard 'New UModeler' action.",
            "UModelerX.CreateObject")]
        public static string CreateObject(
            [ToolParameter("Name of the new GameObject. Leave empty for default.")]
            string name = "",
            [ToolParameter("If true, apply the (px,py,pz) world position. Otherwise use default placement.")]
            bool applyPosition = false,
            [ToolParameter("World X position. Ignored when applyPosition is false.")]
            float px = 0f,
            [ToolParameter("World Y position. Ignored when applyPosition is false.")]
            float py = 0f,
            [ToolParameter("World Z position. Ignored when applyPosition is false.")]
            float pz = 0f)
        {
            try
            {
                UMXActions.NewObject.Invoke(null);
                var go = Selection.activeGameObject;
                var modelerMesh = go != null ? go.GetComponent<UModelerXEditableMesh>() : null;
                if (modelerMesh == null)
                    return "ERROR CREATE_FAILED: NewObject action did not produce an active UModelerXEditableMesh.";

                if (string.IsNullOrEmpty(name) == false)
                    modelerMesh.gameObject.name = name;

                if (applyPosition)
                    modelerMesh.transform.position = new Vector3(px, py, pz);

                var pos = modelerMesh.transform.position;
                return $"Created UModelerX object '{modelerMesh.gameObject.name}' at ({pos.x},{pos.y},{pos.z}).";
            }
            catch (Exception e)
            {
                return $"ERROR UNEXPECTED: {e.Message}";
            }
        }

        // Agent 모드에서 자연어 → 도형 선택을 안정적으로 매핑하기 위해 enum 사용.
        public enum UMXPrimitiveKind
        {
            Box,
            Sphere,
            Cylinder,
            Capsule,
            Cone,
            Torus,
            Pipe,
            Icosphere,
            Stair,
            SpiralStair,
            Room,
            Wedge,
            Arch,
            Dome,
            RegularPolyhedron,
            Superellipsoid,
            NurbsSurface,
            Gear,
            QuadStrip,
            Layout,
            Ngon,
        }

        [AgentTool("Create a UModelerX primitive shape (Box/Sphere/Cylinder/Capsule/Cone/Torus/Pipe/Icosphere/Stair/SpiralStair/Room/Wedge/Arch/Dome/RegularPolyhedron/Superellipsoid/NurbsSurface/Gear/QuadStrip/Ngon). " +
                   "Runs OneClickBuild then applies any shape-specific parameters (-1 means 'use default').",
            "UModelerX.CreatePrimitive")]
        public static string CreatePrimitive(
            [ToolParameter("Primitive shape kind.")]
            UMXPrimitiveKind kind = UMXPrimitiveKind.Box,
            [ToolParameter("Name of the new GameObject. Leave empty for default.")]
            string name = "",
            [ToolParameter("If true, apply (px,py,pz) world position.")]
            bool applyPosition = false,
            [ToolParameter("World X position.")] float px = 0f,
            [ToolParameter("World Y position.")] float py = 0f,
            [ToolParameter("World Z position.")] float pz = 0f,
            [ToolParameter("Box/Stair/SpiralStair/Room/Wedge: width (-1 to skip). QuadStrip: ribbon width.")]
            float Width = -1f,
            [ToolParameter("Box/Cylinder/Capsule/Cone/Pipe/Stair/SpiralStair/Room/Wedge: height. Gear: gear thickness (-1 to skip).")]
            float Height = -1f,
            [ToolParameter("Box/Stair/Room/Wedge/Arch: depth (-1 to skip). QuadStrip: initial straight length.")]
            float Depth = -1f,
            [ToolParameter("Sphere/Cylinder/Capsule/Cone/Icosphere/SpiralStair/Dome/RegularPolyhedron: radius. Gear: bore (center hole) radius (-1 to skip). Ngon: circumradius.")]
            float Radius = -1f,
            [ToolParameter("Torus/Pipe/Arch: outer radius. Gear: tip radius (-1 to skip). QuadStrip: start width scale.")]
            float Radius1 = -1f,
            [ToolParameter("Torus/Pipe/Arch: inner radius. Gear: root radius (must be below tip radius) (-1 to skip). QuadStrip: end width scale.")]
            float Radius2 = -1f,
            [ToolParameter("Room: wall thickness. Gear: tooth width AT THE TIP as a ratio of one tooth pitch (0.05-0.95); the root width comes from Angle (-1 to skip). QuadStrip: solid thickness, 0 = flat single-sided strip. Ngon: extrude thickness, 0 = flat single N-gon face.")]
            float Thickness = -1f,
            [ToolParameter("Stair/SpiralStair: step height (-1 to skip).")]
            float StepHeight = -1f,
            [ToolParameter("SpiralStair: rotation angle in degrees. Gear: pressure angle in degrees, 0-45, default 20 (flank slope; larger means a wider tooth root). Arch: arc angle in degrees, default 180 (-1 to skip). QuadStrip: total twist in degrees.")]
            float Angle = -1f,
            [ToolParameter("Wedge/Arch: Y-axis rotation in degrees (-1 to skip).")]
            float Rotation = -1f,
            [ToolParameter("Sphere/Capsule/Torus/Dome: circumferential segments (-1 to skip).")]
            int Segments = -1,
            [ToolParameter("Capsule/Cone/Torus/Pipe: side count. Arch: arc segments. Gear: number of teeth (-1 to skip). Ngon: vertex count, 3-128 (control point count in curved mode).")]
            int Sides = -1,
            [ToolParameter("Sphere/Capsule/Dome: ring count (-1 to skip).")]
            int Rings = -1,
            [ToolParameter("Icosphere: subdivision order (-1 to skip).")]
            int Order = -1,
            [ToolParameter("SpiralStair: total spiral sweep in degrees, 1-360, default 360 (-1 to skip). Use CounterClockwise for direction.")]
            int SweepAngle = -1,
            [ToolParameter("SpiralStair: if true, the stair spirals counter-clockwise as it climbs.")]
            bool CounterClockwise = false,
            [ToolParameter("SpiralStair: stair (tread) width measured outward from the center radius (-1 to skip).")]
            float StepWidth = -1f,
            [ToolParameter("Box: width segments. QuadStrip: width segments (-1 to skip).")]
            int WidthSegs = -1,
            [ToolParameter("Box: depth segments. QuadStrip: curve segments per span (-1 to skip). Ngon: curve segments per span.")]
            int DepthSegs = -1,
            [ToolParameter("Box: height segments (-1 to skip).")]
            int HeightSegs = -1,
            [ToolParameter("Pipe/Gear: height segments (-1 to skip).")]
            int HeightSegment = -1,
            [ToolParameter("Cylinder: disk segments (-1 to skip).")]
            int DiskSegments = -1,
            [ToolParameter("Cylinder: height segments (-1 to skip).")]
            int HeightSegments = -1,
            [ToolParameter("Superellipsoid: vertical roundness exponent e1 (0.01=cube-like, 1=ellipsoid, >2=concave star; -1 to skip).")]
            float Roundness1 = -1f,
            [ToolParameter("Superellipsoid: horizontal roundness exponent e2 (-1 to skip).")]
            float Roundness2 = -1f,
            [ToolParameter("NurbsSurface: control point count along U. QuadStrip: curve control point count, 2-32 (-1 to skip).")]
            int ControlsU = -1,
            [ToolParameter("NurbsSurface: control point count along V (-1 to skip).")]
            int ControlsV = -1,
            [ToolParameter("QuadStrip: if true, close the curve into a loop.")]
            bool Closed = false,
            [ToolParameter("Ngon: if true, the contour is a closed Catmull-Rom curve through control points (editable in the editor).")]
            bool Curved = false,
            [ToolParameter("RegularPolyhedron: polyhedron kind (Tetrahedron/Hexahedron/Octahedron/Dodecahedron/Icosahedron). Empty to use default.")]
            string PolyhedronType = "")
        {
            try
            {
                var toolType = MapPrimitiveTool(kind);
                if (toolType == null)
                {
                    // 인터랙티브 쉐이프 툴이 없는 종류(Wedge/Arch/Dome/RegularPolyhedron)는 공통 실행 레이어로 위임한다.
                    var request = new CreatePrimitiveRequest
                    {
                        Type = MapPrimitiveType(kind),
                        Name = string.IsNullOrEmpty(name) ? null : name,
                        Position = applyPosition ? new Vector3(px, py, pz) : (Vector3?)null,
                        Width = ToNullable(Width),
                        Height = ToNullable(Height),
                        Depth = ToNullable(Depth),
                        Radius = ToNullable(Radius),
                        Radius1 = ToNullable(Radius1),
                        Radius2 = ToNullable(Radius2),
                        Thickness = ToNullable(Thickness),
                        StepHeight = ToNullable(StepHeight),
                        StepWidth = ToNullable(StepWidth),
                        Angle = ToNullable(Angle),
                        Rotation = ToNullable(Rotation),
                        Segments = ToNullable(Segments),
                        Sides = ToNullable(Sides),
                        Rings = ToNullable(Rings),
                        Order = ToNullable(Order),
                        SweepAngle = ToNullable(SweepAngle),
                        CounterClockwise = CounterClockwise ? (bool?)true : null,
                        Closed = Closed ? (bool?)true : null,
                        Curved = Curved ? (bool?)true : null,
                        WidthSegs = ToNullable(WidthSegs),
                        DepthSegs = ToNullable(DepthSegs),
                        HeightSegs = ToNullable(HeightSegs),
                        HeightSegment = ToNullable(HeightSegment),
                        DiskSegments = ToNullable(DiskSegments),
                        HeightSegments = ToNullable(HeightSegments),
                        Roundness1 = ToNullable(Roundness1),
                        Roundness2 = ToNullable(Roundness2),
                        ControlsU = ToNullable(ControlsU),
                        ControlsV = ToNullable(ControlsV),
                        PolyhedronType = string.IsNullOrEmpty(PolyhedronType) ? null : PolyhedronType,
                    };
                    // ExecuteAsync 는 동기 완료 Task 를 반환하므로 Result 접근이 안전하다.
                    var opResult = CreatePrimitiveOperation.ExecuteAsync(request).Result;
                    return opResult.Success ? opResult.Message : $"ERROR {opResult.Message}";
                }

                UMXActions.NewObject.Invoke(null);

                var go = Selection.activeGameObject;
                var modelerMesh = go != null ? go.GetComponent<UModelerXEditableMesh>() : null;
                if (modelerMesh == null)
                    return "ERROR CREATE_FAILED: NewObject action did not produce an active UModelerXEditableMesh.";

                if (string.IsNullOrEmpty(name) == false)
                    modelerMesh.gameObject.name = name;

                if (applyPosition)
                    modelerMesh.transform.position = new Vector3(px, py, pz);

                var toolSet = UMXToolSet.GetToolSetByEditorType(typeof(ModelingEditor));
                if (toolSet == null)
                    return "ERROR TOOLSET_UNAVAILABLE: ModelingEditor tool set is not available.";

                if (toolSet.Contains(toolType) == false)
                    return $"ERROR TOOL_NOT_FOUND: {toolType.Name} is not registered in ModelingEditor tool set.";

                toolSet.SetCurrentTool(toolSet[toolType]);

                if ((toolSet.CurrentTool is ShapeTool shapeTool && shapeTool.CanOneClickBuild) == false)
                    return $"ERROR ONECLICK_UNSUPPORTED: {toolType.Name} does not support OneClickBuild.";

                shapeTool.OneClickBuild();

                var st = shapeTool.GetType();
                var applied = new System.Collections.Generic.List<string>();
                TrySetFloat(st, shapeTool, "Width", Width, applied);
                TrySetFloat(st, shapeTool, "Height", Height, applied);
                TrySetFloat(st, shapeTool, "Depth", Depth, applied);
                TrySetFloat(st, shapeTool, "Radius", Radius, applied);
                TrySetFloat(st, shapeTool, "Radius1", Radius1, applied);
                TrySetFloat(st, shapeTool, "Radius2", Radius2, applied);
                TrySetFloat(st, shapeTool, "Thickness", Thickness, applied);
                TrySetFloat(st, shapeTool, "StepHeight", StepHeight, applied);
                TrySetFloat(st, shapeTool, "Angle", Angle, applied);
                TrySetInt(st, shapeTool, "Segments", Segments, applied);
                TrySetInt(st, shapeTool, "Sides", Sides, applied);
                TrySetInt(st, shapeTool, "Rings", Rings, applied);
                TrySetInt(st, shapeTool, "Order", Order, applied);
                // 인터랙티브 쉐이프 툴의 프로퍼티 이름은 여전히 Curvature 다(의미는 나선 총 회전 각도).
                TrySetInt(st, shapeTool, "Curvature", SweepAngle, applied);
                if (CounterClockwise)
                {
                    TrySetBool(st, shapeTool, "CounterClockwise", true, applied);
                }
                TrySetInt(st, shapeTool, "WidthSegs", WidthSegs, applied);
                TrySetInt(st, shapeTool, "DepthSegs", DepthSegs, applied);
                TrySetInt(st, shapeTool, "HeightSegs", HeightSegs, applied);
                TrySetInt(st, shapeTool, "HeightSegment", HeightSegment, applied);
                TrySetInt(st, shapeTool, "DiskSegments", DiskSegments, applied);
                TrySetInt(st, shapeTool, "HeightSegments", HeightSegments, applied);

                Undo.IncrementCurrentGroup();

                var appliedStr = applied.Count == 0 ? "(defaults)" : string.Join(", ", applied);
                return $"Created UModelerX {kind} '{modelerMesh.gameObject.name}'. Applied: {appliedStr}.";
            }
            catch (Exception e)
            {
                return $"ERROR UNEXPECTED: {e.Message}";
            }
        }

        [AgentTool("Add a modifier to an existing UMXParametricShape or UModelerX editable mesh. Identify target by GameObject name or rely on current Selection.",
            "UModelerX.AddModifier")]
        public static string AddModifier(
            [ToolParameter("Modifier type short name (Bend, Mirror, Subdivide, Push, Shell, Decimate, LinearArray, RadialArray, FFD2x2x2, FFD3x3x3, FFD4x4x4) or full type name.")]
            string type,
            [ToolParameter("Target UMXParametricShape or UModelerX GameObject name. Leave empty to use current Selection.")]
            string targetName = "",
            [ToolParameter("Rebuild mesh after adding. Default true.")]
            bool build = true)
        {
            var request = new AddModifierRequest
            {
                Type = type,
                TargetName = string.IsNullOrEmpty(targetName) ? null : targetName,
                Build = build,
            };
            var result = AddModifierOperation.Execute(request);
            if (result.Success)
            {
                return result.Message;
            }
            return $"ERROR {result.Message}";
        }

        [AgentTool("Create a parametric UModelerX shape whose parameters stay live on a UMXParametricShape component. " +
                   "Unlike CreatePrimitive, the shape can be adjusted later with UpdateParametricShape. " +
                   "Modifiers work while the object stays parametric. Set umodelerize true only for explicit editable-mesh conversion. -1 means 'use default'.",
            "UModelerX.CreateParametricShape")]
        public static string CreateParametricShape(
            [ToolParameter("Parametric shape kind.")]
            UMXPrimitiveKind kind = UMXPrimitiveKind.Box,
            [ToolParameter("Name of the new GameObject. Leave empty for default.")]
            string name = "",
            [ToolParameter("If true, apply (px,py,pz) world position.")]
            bool applyPosition = false,
            [ToolParameter("World X position.")] float px = 0f,
            [ToolParameter("World Y position.")] float py = 0f,
            [ToolParameter("World Z position.")] float pz = 0f,
            [ToolParameter("Explicitly convert to a UModelerX editable mesh. Modifiers work without this. Default false.")]
            bool umodelerize = false,
            [ToolParameter("Box/Stair/SpiralStair/Room/Wedge: width (-1 to skip). QuadStrip: ribbon width.")]
            float Width = -1f,
            [ToolParameter("Box/Cylinder/Capsule/Cone/Pipe/Stair/SpiralStair/Room/Wedge: height. Gear: gear thickness (-1 to skip).")]
            float Height = -1f,
            [ToolParameter("Box/Stair/Room/Wedge/Arch: depth (-1 to skip). QuadStrip: initial straight length.")]
            float Depth = -1f,
            [ToolParameter("Sphere/Cylinder/Capsule/Cone/Icosphere/SpiralStair/Dome/RegularPolyhedron: radius. Gear: bore (center hole) radius (-1 to skip). Ngon: circumradius.")]
            float Radius = -1f,
            [ToolParameter("Torus/Pipe/Arch: outer radius. Gear: tip radius (-1 to skip). QuadStrip: start width scale.")]
            float Radius1 = -1f,
            [ToolParameter("Torus/Pipe/Arch: inner radius. Gear: root radius (must be below tip radius) (-1 to skip). QuadStrip: end width scale.")]
            float Radius2 = -1f,
            [ToolParameter("Room: wall thickness. Gear: tooth width AT THE TIP as a ratio of one tooth pitch (0.05-0.95); the root width comes from Angle (-1 to skip). QuadStrip: solid thickness, 0 = flat single-sided strip. Ngon: extrude thickness, 0 = flat single N-gon face.")]
            float Thickness = -1f,
            [ToolParameter("Stair/SpiralStair: step height (-1 to skip).")]
            float StepHeight = -1f,
            [ToolParameter("SpiralStair: rotation angle in degrees. Gear: pressure angle in degrees, 0-45, default 20 (flank slope; larger means a wider tooth root). Arch: arc angle in degrees, default 180 (-1 to skip). QuadStrip: total twist in degrees.")]
            float Angle = -1f,
            [ToolParameter("Wedge/Arch: Y-axis rotation in degrees (-1 to skip).")]
            float Rotation = -1f,
            [ToolParameter("Sphere/Capsule/Torus/Dome: circumferential segments (-1 to skip).")]
            int Segments = -1,
            [ToolParameter("Capsule/Cone/Torus/Pipe: side count. Arch: arc segments. Gear: number of teeth (-1 to skip). Ngon: vertex count, 3-128 (control point count in curved mode).")]
            int Sides = -1,
            [ToolParameter("Sphere/Capsule/Dome: ring count (-1 to skip).")]
            int Rings = -1,
            [ToolParameter("Icosphere: subdivision order (-1 to skip).")]
            int Order = -1,
            [ToolParameter("SpiralStair: total spiral sweep in degrees, 1-360, default 360 (-1 to skip). Use CounterClockwise for direction.")]
            int SweepAngle = -1,
            [ToolParameter("SpiralStair: if true, the stair spirals counter-clockwise as it climbs.")]
            bool CounterClockwise = false,
            [ToolParameter("SpiralStair: stair (tread) width measured outward from the center radius (-1 to skip).")]
            float StepWidth = -1f,
            [ToolParameter("Box: width segments. QuadStrip: width segments (-1 to skip).")]
            int WidthSegs = -1,
            [ToolParameter("Box: depth segments. QuadStrip: curve segments per span (-1 to skip). Ngon: curve segments per span.")]
            int DepthSegs = -1,
            [ToolParameter("Box: height segments (-1 to skip).")]
            int HeightSegs = -1,
            [ToolParameter("Pipe/Gear: height segments (-1 to skip).")]
            int HeightSegment = -1,
            [ToolParameter("Cylinder: disk segments (-1 to skip).")]
            int DiskSegments = -1,
            [ToolParameter("Cylinder: height segments (-1 to skip).")]
            int HeightSegments = -1,
            [ToolParameter("Superellipsoid: vertical roundness exponent e1 (0.01=cube-like, 1=ellipsoid, >2=concave star; -1 to skip).")]
            float Roundness1 = -1f,
            [ToolParameter("Superellipsoid: horizontal roundness exponent e2 (-1 to skip).")]
            float Roundness2 = -1f,
            [ToolParameter("NurbsSurface: control point count along U. QuadStrip: curve control point count, 2-32 (-1 to skip).")]
            int ControlsU = -1,
            [ToolParameter("NurbsSurface: control point count along V (-1 to skip).")]
            int ControlsV = -1,
            [ToolParameter("QuadStrip: if true, close the curve into a loop.")]
            bool Closed = false,
            [ToolParameter("Ngon: if true, the contour is a closed Catmull-Rom curve through control points (editable in the editor).")]
            bool Curved = false,
            [ToolParameter("If true, apply (ox,oy,oz) as the anchor offset from the parent-bounds anchor point.")]
            bool applyAnchorOffset = false,
            [ToolParameter("Anchor offset X.")] float ox = 0f,
            [ToolParameter("Anchor offset Y.")] float oy = 0f,
            [ToolParameter("Anchor offset Z.")] float oz = 0f,
            [ToolParameter("If true, apply the colliderMode value below.")]
            bool applyColliderMode = false,
            [ToolParameter("Collider mode: hide the renderable and represent the shape with a collider (primitive collider for Box/Sphere/Icosphere/Capsule/Layout, MeshCollider otherwise).")]
            bool colliderMode = false,
            [ToolParameter("RegularPolyhedron: polyhedron kind (Tetrahedron/Hexahedron/Octahedron/Dodecahedron/Icosahedron). Empty to use default.")]
            string PolyhedronType = "",
            [ToolParameter("Material asset path (Assets/.../X.mat) or asset name to apply. Empty to keep the default material.")]
            string Material = "",
            [ToolParameter("Hotspot layout asset path (Assets/.../X.asset) or asset name. When set, every face UV is fitted to the hotspot rects instead of the default procedural unwrap. Empty to keep the default UVs.")]
            string Hotspot = "")
        {
            try
            {
                var request = new CreateParametricShapeRequest
                {
                    Type = MapPrimitiveType(kind),
                    Name = string.IsNullOrEmpty(name) ? null : name,
                    Position = applyPosition ? new Vector3(px, py, pz) : (Vector3?)null,
                    Umodelerize = umodelerize,
                    Width = ToNullable(Width),
                    Height = ToNullable(Height),
                    Depth = ToNullable(Depth),
                    Radius = ToNullable(Radius),
                    Radius1 = ToNullable(Radius1),
                    Radius2 = ToNullable(Radius2),
                    Thickness = ToNullable(Thickness),
                    StepHeight = ToNullable(StepHeight),
                    StepWidth = ToNullable(StepWidth),
                    Angle = ToNullable(Angle),
                    Rotation = ToNullable(Rotation),
                    Segments = ToNullable(Segments),
                    Sides = ToNullable(Sides),
                    Rings = ToNullable(Rings),
                    Order = ToNullable(Order),
                    SweepAngle = ToNullable(SweepAngle),
                    CounterClockwise = CounterClockwise ? (bool?)true : null,
                    Closed = Closed ? (bool?)true : null,
                    Curved = Curved ? (bool?)true : null,
                    AnchorOffset = applyAnchorOffset ? new Vector3(ox, oy, oz) : (Vector3?)null,
                    ColliderMode = applyColliderMode ? (bool?)colliderMode : null,
                    WidthSegs = ToNullable(WidthSegs),
                    DepthSegs = ToNullable(DepthSegs),
                    HeightSegs = ToNullable(HeightSegs),
                    HeightSegment = ToNullable(HeightSegment),
                    DiskSegments = ToNullable(DiskSegments),
                    HeightSegments = ToNullable(HeightSegments),
                    Roundness1 = ToNullable(Roundness1),
                    Roundness2 = ToNullable(Roundness2),
                    ControlsU = ToNullable(ControlsU),
                    ControlsV = ToNullable(ControlsV),
                    PolyhedronType = string.IsNullOrEmpty(PolyhedronType) ? null : PolyhedronType,
                    Material = string.IsNullOrEmpty(Material) ? null : Material,
                    Hotspot = string.IsNullOrEmpty(Hotspot) ? null : Hotspot,
                };
                var result = ParametricShapeOperations.ExecuteCreate(request);
                return result.Success ? result.Message : $"ERROR {result.Message}";
            }
            catch (Exception e)
            {
                return $"ERROR UNEXPECTED: {e.Message}";
            }
        }

        [AgentTool("Update parameters of an existing UMXParametricShape and regenerate its mesh. " +
                   "Identify target by GameObject name or rely on current Selection. -1 means 'keep current value'. " +
                   "Parametric modifiers stay on the UMXParametricShape; umodelerize is only an explicit editable-mesh conversion option.",
            "UModelerX.UpdateParametricShape")]
        public static string UpdateParametricShape(
            [ToolParameter("Target GameObject name. Leave empty to use current Selection.")]
            string targetName = "",
            [ToolParameter("If true, change the shape kind to 'kind'.")]
            bool changeKind = false,
            [ToolParameter("New shape kind. Ignored when changeKind is false.")]
            UMXPrimitiveKind kind = UMXPrimitiveKind.Box,
            [ToolParameter("Explicitly convert a standalone shape into a UModelerX editable mesh. This removes the parametric component, so the shape parameters can no longer be updated afterwards. Ignored if already converted.")]
            bool umodelerize = false,
            [ToolParameter("Box/Stair/SpiralStair/Room/Wedge: width (-1 to keep). QuadStrip: ribbon width.")]
            float Width = -1f,
            [ToolParameter("Box/Cylinder/Capsule/Cone/Pipe/Stair/SpiralStair/Room/Wedge: height. Gear: gear thickness (-1 to keep).")]
            float Height = -1f,
            [ToolParameter("Box/Stair/Room/Wedge/Arch: depth (-1 to keep). QuadStrip: initial straight length.")]
            float Depth = -1f,
            [ToolParameter("Sphere/Cylinder/Capsule/Cone/Icosphere/SpiralStair/Dome/RegularPolyhedron: radius. Gear: bore (center hole) radius (-1 to keep). Ngon: circumradius.")]
            float Radius = -1f,
            [ToolParameter("Torus/Pipe/Arch: outer radius. Gear: tip radius (-1 to keep). QuadStrip: start width scale.")]
            float Radius1 = -1f,
            [ToolParameter("Torus/Pipe/Arch: inner radius. Gear: root radius (must be below tip radius) (-1 to keep). QuadStrip: end width scale.")]
            float Radius2 = -1f,
            [ToolParameter("Room: wall thickness. Gear: tooth width AT THE TIP as a ratio of one tooth pitch (0.05-0.95); the root width comes from Angle (-1 to keep). QuadStrip: solid thickness, 0 = flat single-sided strip. Ngon: extrude thickness, 0 = flat single N-gon face.")]
            float Thickness = -1f,
            [ToolParameter("Stair/SpiralStair: step height (-1 to keep).")]
            float StepHeight = -1f,
            [ToolParameter("SpiralStair: rotation angle in degrees. Gear: pressure angle in degrees, 0-45, default 20 (flank slope; larger means a wider tooth root). Arch: arc angle in degrees (-1 to keep). QuadStrip: total twist in degrees.")]
            float Angle = -1f,
            [ToolParameter("Wedge/Arch: Y-axis rotation in degrees (-1 to keep).")]
            float Rotation = -1f,
            [ToolParameter("Sphere/Capsule/Torus/Dome: circumferential segments (-1 to keep).")]
            int Segments = -1,
            [ToolParameter("Capsule/Cone/Torus/Pipe: side count. Arch: arc segments. Gear: number of teeth (-1 to keep). Ngon: vertex count, 3-128 (control point count in curved mode).")]
            int Sides = -1,
            [ToolParameter("Sphere/Capsule/Dome: ring count (-1 to keep).")]
            int Rings = -1,
            [ToolParameter("Icosphere: subdivision order (-1 to keep).")]
            int Order = -1,
            [ToolParameter("SpiralStair: total spiral sweep in degrees, 1-360 (-1 to keep). Use changeDirection/counterClockwise for direction.")]
            int SweepAngle = -1,
            [ToolParameter("If true, apply the counterClockwise value below. Leave false to keep the current direction.")]
            bool changeDirection = false,
            [ToolParameter("SpiralStair: if true, the stair spirals counter-clockwise as it climbs. Ignored when changeDirection is false.")]
            bool counterClockwise = false,
            [ToolParameter("SpiralStair: stair (tread) width measured outward from the center radius (-1 to keep).")]
            float StepWidth = -1f,
            [ToolParameter("Box: width segments. QuadStrip: width segments (-1 to keep).")]
            int WidthSegs = -1,
            [ToolParameter("Box: depth segments. QuadStrip: curve segments per span (-1 to keep). Ngon: curve segments per span.")]
            int DepthSegs = -1,
            [ToolParameter("Box: height segments (-1 to keep).")]
            int HeightSegs = -1,
            [ToolParameter("Pipe/Gear: height segments (-1 to keep).")]
            int HeightSegment = -1,
            [ToolParameter("Cylinder: disk segments (-1 to keep).")]
            int DiskSegments = -1,
            [ToolParameter("Cylinder: height segments (-1 to keep).")]
            int HeightSegments = -1,
            [ToolParameter("Superellipsoid: vertical roundness exponent e1 (0.01=cube-like, 1=ellipsoid, >2=concave star; -1 to keep).")]
            float Roundness1 = -1f,
            [ToolParameter("Superellipsoid: horizontal roundness exponent e2 (-1 to keep).")]
            float Roundness2 = -1f,
            [ToolParameter("NurbsSurface: control point count along U. QuadStrip: curve control point count, 2-32 (-1 to keep).")]
            int ControlsU = -1,
            [ToolParameter("NurbsSurface: control point count along V (-1 to keep).")]
            int ControlsV = -1,
            [ToolParameter("QuadStrip: if true, close the curve into a loop.")]
            bool Closed = false,
            [ToolParameter("If true, apply the curved value below (Ngon curve mode can be turned on or off).")]
            bool applyCurved = false,
            [ToolParameter("Ngon: if true, the contour is a closed Catmull-Rom curve through control points.")]
            bool curved = false,
            [ToolParameter("If true, apply (ox,oy,oz) as the anchor offset from the parent-bounds anchor point.")]
            bool applyAnchorOffset = false,
            [ToolParameter("Anchor offset X.")] float ox = 0f,
            [ToolParameter("Anchor offset Y.")] float oy = 0f,
            [ToolParameter("Anchor offset Z.")] float oz = 0f,
            [ToolParameter("If true, apply the colliderMode value below.")]
            bool applyColliderMode = false,
            [ToolParameter("Collider mode: hide the renderable and represent the shape with a collider (primitive collider for Box/Sphere/Icosphere/Capsule/Layout, MeshCollider otherwise).")]
            bool colliderMode = false,
            [ToolParameter("RegularPolyhedron: polyhedron kind (Tetrahedron/Hexahedron/Octahedron/Dodecahedron/Icosahedron). Empty to keep.")]
            string PolyhedronType = "",
            [ToolParameter("Material asset path (Assets/.../X.mat) or asset name to apply. Empty to keep the current material.")]
            string Material = "",
            [ToolParameter("Hotspot layout asset path (Assets/.../X.asset) or asset name. When set, every face UV is fitted to the hotspot rects instead of the default procedural unwrap. Empty to keep the current hotspot.")]
            string Hotspot = "")
        {
            try
            {
                var request = new UpdateParametricShapeRequest
                {
                    TargetName = string.IsNullOrEmpty(targetName) ? null : targetName,
                    Type = changeKind ? MapPrimitiveType(kind) : (UMXPrimitiveType?)null,
                    Umodelerize = umodelerize ? true : (bool?)null,
                    Width = ToNullable(Width),
                    Height = ToNullable(Height),
                    Depth = ToNullable(Depth),
                    Radius = ToNullable(Radius),
                    Radius1 = ToNullable(Radius1),
                    Radius2 = ToNullable(Radius2),
                    Thickness = ToNullable(Thickness),
                    StepHeight = ToNullable(StepHeight),
                    StepWidth = ToNullable(StepWidth),
                    Angle = ToNullable(Angle),
                    Rotation = ToNullable(Rotation),
                    Segments = ToNullable(Segments),
                    Sides = ToNullable(Sides),
                    Rings = ToNullable(Rings),
                    Order = ToNullable(Order),
                    SweepAngle = ToNullable(SweepAngle),
                    // 방향은 명시적으로 바꾸겠다고 한 경우에만 적용한다(그냥 false 를 보내면 기존 방향을 덮어쓴다).
                    CounterClockwise = changeDirection ? (bool?)counterClockwise : null,
                    Closed = Closed ? (bool?)true : null,
                    Curved = applyCurved ? (bool?)curved : null,
                    AnchorOffset = applyAnchorOffset ? new Vector3(ox, oy, oz) : (Vector3?)null,
                    ColliderMode = applyColliderMode ? (bool?)colliderMode : null,
                    WidthSegs = ToNullable(WidthSegs),
                    DepthSegs = ToNullable(DepthSegs),
                    HeightSegs = ToNullable(HeightSegs),
                    HeightSegment = ToNullable(HeightSegment),
                    DiskSegments = ToNullable(DiskSegments),
                    HeightSegments = ToNullable(HeightSegments),
                    Roundness1 = ToNullable(Roundness1),
                    Roundness2 = ToNullable(Roundness2),
                    ControlsU = ToNullable(ControlsU),
                    ControlsV = ToNullable(ControlsV),
                    PolyhedronType = string.IsNullOrEmpty(PolyhedronType) ? null : PolyhedronType,
                    Material = string.IsNullOrEmpty(Material) ? null : Material,
                    Hotspot = string.IsNullOrEmpty(Hotspot) ? null : Hotspot,
                };
                var result = ParametricShapeOperations.ExecuteUpdate(request);
                return result.Success ? result.Message : $"ERROR {result.Message}";
            }
            catch (Exception e)
            {
                return $"ERROR UNEXPECTED: {e.Message}";
            }
        }

        // -1 sentinel → null 변환.
        private static float? ToNullable(float value)
        {
            return value < 0f ? (float?)null : value;
        }

        private static int? ToNullable(int value)
        {
            return value < 0 ? (int?)null : value;
        }

        private static UMXPrimitiveType MapPrimitiveType(UMXPrimitiveKind kind)
        {
            switch (kind)
            {
                case UMXPrimitiveKind.Box: return UMXPrimitiveType.Box;
                case UMXPrimitiveKind.Sphere: return UMXPrimitiveType.Sphere;
                case UMXPrimitiveKind.Cylinder: return UMXPrimitiveType.Cylinder;
                case UMXPrimitiveKind.Capsule: return UMXPrimitiveType.Capsule;
                case UMXPrimitiveKind.Cone: return UMXPrimitiveType.Cone;
                case UMXPrimitiveKind.Torus: return UMXPrimitiveType.Torus;
                case UMXPrimitiveKind.Pipe: return UMXPrimitiveType.Pipe;
                case UMXPrimitiveKind.Icosphere: return UMXPrimitiveType.Icosphere;
                case UMXPrimitiveKind.Stair: return UMXPrimitiveType.Stair;
                case UMXPrimitiveKind.SpiralStair: return UMXPrimitiveType.SpiralStair;
                case UMXPrimitiveKind.Room: return UMXPrimitiveType.Room;
                case UMXPrimitiveKind.Wedge: return UMXPrimitiveType.Wedge;
                case UMXPrimitiveKind.Arch: return UMXPrimitiveType.Arch;
                case UMXPrimitiveKind.Dome: return UMXPrimitiveType.Dome;
                case UMXPrimitiveKind.RegularPolyhedron: return UMXPrimitiveType.RegularPolyhedron;
                case UMXPrimitiveKind.Superellipsoid: return UMXPrimitiveType.Superellipsoid;
                case UMXPrimitiveKind.NurbsSurface: return UMXPrimitiveType.NurbsSurface;
                case UMXPrimitiveKind.Gear: return UMXPrimitiveType.Gear;
                case UMXPrimitiveKind.QuadStrip: return UMXPrimitiveType.QuadStrip;
                case UMXPrimitiveKind.Layout: return UMXPrimitiveType.Layout;
                case UMXPrimitiveKind.Ngon: return UMXPrimitiveType.Ngon;
                default: return UMXPrimitiveType.Box;
            }
        }

        private static Type MapPrimitiveTool(UMXPrimitiveKind kind)
        {
            switch (kind)
            {
                case UMXPrimitiveKind.Box:         return typeof(BoxTool);
                case UMXPrimitiveKind.Sphere:      return typeof(SphereTool);
                case UMXPrimitiveKind.Cylinder:    return typeof(CylinderTool);
                case UMXPrimitiveKind.Capsule:     return typeof(CapsuleTool);
                case UMXPrimitiveKind.Cone:        return typeof(ConeTool);
                case UMXPrimitiveKind.Torus:       return typeof(TorusTool);
                case UMXPrimitiveKind.Pipe:        return typeof(PipeTool);
                case UMXPrimitiveKind.Icosphere:   return typeof(IcosphereTool);
                case UMXPrimitiveKind.Stair:       return typeof(StairTool);
                case UMXPrimitiveKind.SpiralStair: return typeof(SpiralStairTool);
                case UMXPrimitiveKind.Room:        return typeof(RoomTool);
                default:                           return null;
            }
        }

        // -1 sentinel 은 "건너뜀"으로 해석. tool 의 동명 property 에 리플렉션으로 주입.
        private static void TrySetFloat(Type type, object target, string name, float value, System.Collections.Generic.List<string> applied)
        {
            if (value < 0f)
                return;
            var prop = type.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (prop == null || prop.CanWrite == false || prop.PropertyType != typeof(float))
                return;
            try
            {
                prop.SetValue(target, value);
                applied.Add($"{name}={value}");
            }
            catch (TargetInvocationException) { }
        }

        private static void TrySetBool(Type type, object target, string name, bool value, System.Collections.Generic.List<string> applied)
        {
            var prop = type.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (prop == null || prop.CanWrite == false || prop.PropertyType != typeof(bool))
                return;
            try
            {
                prop.SetValue(target, value);
                applied.Add($"{name}={value}");
            }
            catch (TargetInvocationException) { }
        }

        private static void TrySetInt(Type type, object target, string name, int value, System.Collections.Generic.List<string> applied)
        {
            if (value < 0)
                return;
            var prop = type.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (prop == null || prop.CanWrite == false || prop.PropertyType != typeof(int))
                return;
            try
            {
                prop.SetValue(target, value);
                applied.Add($"{name}={value}");
            }
            catch (TargetInvocationException) { }
        }
    }
}
