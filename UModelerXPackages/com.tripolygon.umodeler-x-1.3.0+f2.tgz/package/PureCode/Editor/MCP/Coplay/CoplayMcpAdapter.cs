using MCPForUnity.Editor.Helpers;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.MCP.Coplay
{
    // CoplayDev MCP(com.coplaydev.unity-mcp) 어댑터 전용 변환 헬퍼.
    // JObject 파싱과 응답 매핑만 담당하고 실제 실행은 Core 의 *Operation 으로 위임한다.
    internal static class CoplayMcpAdapter
    {
        // ── 파라미터 파싱 ────────────────────────────────────────────────────

        // {x,y,z} 형태의 JObject 또는 [x,y,z] 배열을 Vector3 로 파싱한다. 없으면 null.
        internal static Vector3? TryReadVector3(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null)
                return null;

            if (token is JObject obj)
            {
                float? x = obj["x"]?.ToObject<float?>();
                float? y = obj["y"]?.ToObject<float?>();
                float? z = obj["z"]?.ToObject<float?>();
                return new Vector3(x ?? 0f, y ?? 0f, z ?? 0f);
            }

            if (token is JArray arr && arr.Count >= 3)
                return new Vector3(arr[0].ToObject<float>(), arr[1].ToObject<float>(), arr[2].ToObject<float>());

            return null;
        }

        internal static CreateUMXObjectRequest BuildCreateUMXObjectRequest(JObject @params)
        {
            return new CreateUMXObjectRequest
            {
                Name = @params["name"]?.ToString(),
                Position = TryReadVector3(@params["position"]),
            };
        }

        internal static CreatePrimitiveRequest BuildCreatePrimitiveRequest(JObject @params, out string typeError)
        {
            typeError = null;
            var typeStr = @params["type"]?.ToString();
            if (string.IsNullOrWhiteSpace(typeStr))
            {
                typeError = "PRIMITIVE_TYPE_REQUIRED: 'type' parameter cannot be empty.";
                return null;
            }
            if (System.Enum.TryParse<UMXPrimitiveType>(typeStr, ignoreCase: true, out var primType) == false)
            {
                typeError = $"UNSUPPORTED_PRIMITIVE: {typeStr}";
                return null;
            }

            return new CreatePrimitiveRequest
            {
                Type = primType,
                Name = @params["name"]?.ToString(),
                Position = TryReadVector3(@params["position"]),

                Width = @params["Width"]?.ToObject<float?>(),
                Height = @params["Height"]?.ToObject<float?>(),
                Depth = @params["Depth"]?.ToObject<float?>(),
                Radius = @params["Radius"]?.ToObject<float?>(),
                Radius1 = @params["Radius1"]?.ToObject<float?>(),
                Radius2 = @params["Radius2"]?.ToObject<float?>(),
                Thickness = @params["Thickness"]?.ToObject<float?>(),
                StepHeight = @params["StepHeight"]?.ToObject<float?>(),
                StepWidth = @params["StepWidth"]?.ToObject<float?>(),
                Angle = @params["Angle"]?.ToObject<float?>(),
                Rotation = @params["Rotation"]?.ToObject<float?>(),

                Segments = @params["Segments"]?.ToObject<int?>(),
                Sides = @params["Sides"]?.ToObject<int?>(),
                Rings = @params["Rings"]?.ToObject<int?>(),
                Order = @params["Order"]?.ToObject<int?>(),
                SweepAngle = @params["SweepAngle"]?.ToObject<int?>(),
                CounterClockwise = @params["CounterClockwise"]?.ToObject<bool?>(),
                WidthSegs = @params["WidthSegs"]?.ToObject<int?>(),
                DepthSegs = @params["DepthSegs"]?.ToObject<int?>(),
                HeightSegs = @params["HeightSegs"]?.ToObject<int?>(),
                HeightSegment = @params["HeightSegment"]?.ToObject<int?>(),
                DiskSegments = @params["DiskSegments"]?.ToObject<int?>(),
                HeightSegments = @params["HeightSegments"]?.ToObject<int?>(),

                PolyhedronType = @params["PolyhedronType"]?.ToString(),
            };
        }

        internal static AddModifierRequest BuildAddModifierRequest(JObject @params)
        {
            return new AddModifierRequest
            {
                Type = @params["type"]?.ToString(),
                TargetName = @params["targetName"]?.ToString(),
                Build = @params["build"]?.ToObject<bool?>() ?? true,
            };
        }

        internal static CreateParametricShapeRequest BuildCreateParametricShapeRequest(JObject @params, out string typeError)
        {
            typeError = null;
            var typeStr = @params["type"]?.ToString();
            if (string.IsNullOrWhiteSpace(typeStr))
            {
                typeError = "PRIMITIVE_TYPE_REQUIRED: 'type' parameter cannot be empty.";
                return null;
            }
            if (System.Enum.TryParse<UMXPrimitiveType>(typeStr, ignoreCase: true, out var primType) == false)
            {
                typeError = $"UNSUPPORTED_PRIMITIVE: {typeStr}";
                return null;
            }

            return new CreateParametricShapeRequest
            {
                Type = primType,
                Name = @params["name"]?.ToString(),
                Position = TryReadVector3(@params["position"]),
                Umodelerize = @params["umodelerize"]?.ToObject<bool?>() ?? false,

                Width = @params["Width"]?.ToObject<float?>(),
                Height = @params["Height"]?.ToObject<float?>(),
                Depth = @params["Depth"]?.ToObject<float?>(),
                Radius = @params["Radius"]?.ToObject<float?>(),
                Radius1 = @params["Radius1"]?.ToObject<float?>(),
                Radius2 = @params["Radius2"]?.ToObject<float?>(),
                Thickness = @params["Thickness"]?.ToObject<float?>(),
                StepHeight = @params["StepHeight"]?.ToObject<float?>(),
                StepWidth = @params["StepWidth"]?.ToObject<float?>(),
                Angle = @params["Angle"]?.ToObject<float?>(),
                Rotation = @params["Rotation"]?.ToObject<float?>(),

                Segments = @params["Segments"]?.ToObject<int?>(),
                Sides = @params["Sides"]?.ToObject<int?>(),
                Rings = @params["Rings"]?.ToObject<int?>(),
                Order = @params["Order"]?.ToObject<int?>(),
                SweepAngle = @params["SweepAngle"]?.ToObject<int?>(),
                CounterClockwise = @params["CounterClockwise"]?.ToObject<bool?>(),
                WidthSegs = @params["WidthSegs"]?.ToObject<int?>(),
                DepthSegs = @params["DepthSegs"]?.ToObject<int?>(),
                HeightSegs = @params["HeightSegs"]?.ToObject<int?>(),
                HeightSegment = @params["HeightSegment"]?.ToObject<int?>(),
                DiskSegments = @params["DiskSegments"]?.ToObject<int?>(),
                HeightSegments = @params["HeightSegments"]?.ToObject<int?>(),

                Roundness1 = @params["Roundness1"]?.ToObject<float?>(),
                Roundness2 = @params["Roundness2"]?.ToObject<float?>(),
                ControlsU = @params["ControlsU"]?.ToObject<int?>(),
                ControlsV = @params["ControlsV"]?.ToObject<int?>(),
                Closed = @params["Closed"]?.ToObject<bool?>(),
                Curved = @params["Curved"]?.ToObject<bool?>(),
                ColliderMode = @params["ColliderMode"]?.ToObject<bool?>(),

                // 상위 앵커: 오프셋(Vector3)과 비율 모드 필드명 목록
                AnchorOffset = TryReadVector3(@params["AnchorOffset"]),
                RatioParameters = @params["RatioParameters"]?.ToObject<string[]>(),

                PolyhedronType = @params["PolyhedronType"]?.ToString(),
                Material = @params["Material"]?.ToString(),
                Hotspot = @params["Hotspot"]?.ToString(),
            };
        }

        internal static UpdateParametricShapeRequest BuildUpdateParametricShapeRequest(JObject @params, out string typeError)
        {
            typeError = null;

            UMXPrimitiveType? type = null;
            var typeStr = @params["type"]?.ToString();
            if (string.IsNullOrWhiteSpace(typeStr) == false)
            {
                if (System.Enum.TryParse<UMXPrimitiveType>(typeStr, ignoreCase: true, out var primType) == false)
                {
                    typeError = $"UNSUPPORTED_PRIMITIVE: {typeStr}";
                    return null;
                }
                type = primType;
            }

            return new UpdateParametricShapeRequest
            {
                TargetName = @params["targetName"]?.ToString(),
                Type = type,
                Umodelerize = @params["umodelerize"]?.ToObject<bool?>(),

                Width = @params["Width"]?.ToObject<float?>(),
                Height = @params["Height"]?.ToObject<float?>(),
                Depth = @params["Depth"]?.ToObject<float?>(),
                Radius = @params["Radius"]?.ToObject<float?>(),
                Radius1 = @params["Radius1"]?.ToObject<float?>(),
                Radius2 = @params["Radius2"]?.ToObject<float?>(),
                Thickness = @params["Thickness"]?.ToObject<float?>(),
                StepHeight = @params["StepHeight"]?.ToObject<float?>(),
                StepWidth = @params["StepWidth"]?.ToObject<float?>(),
                Angle = @params["Angle"]?.ToObject<float?>(),
                Rotation = @params["Rotation"]?.ToObject<float?>(),

                Segments = @params["Segments"]?.ToObject<int?>(),
                Sides = @params["Sides"]?.ToObject<int?>(),
                Rings = @params["Rings"]?.ToObject<int?>(),
                Order = @params["Order"]?.ToObject<int?>(),
                SweepAngle = @params["SweepAngle"]?.ToObject<int?>(),
                CounterClockwise = @params["CounterClockwise"]?.ToObject<bool?>(),
                WidthSegs = @params["WidthSegs"]?.ToObject<int?>(),
                DepthSegs = @params["DepthSegs"]?.ToObject<int?>(),
                HeightSegs = @params["HeightSegs"]?.ToObject<int?>(),
                HeightSegment = @params["HeightSegment"]?.ToObject<int?>(),
                DiskSegments = @params["DiskSegments"]?.ToObject<int?>(),
                HeightSegments = @params["HeightSegments"]?.ToObject<int?>(),

                Roundness1 = @params["Roundness1"]?.ToObject<float?>(),
                Roundness2 = @params["Roundness2"]?.ToObject<float?>(),
                ControlsU = @params["ControlsU"]?.ToObject<int?>(),
                ControlsV = @params["ControlsV"]?.ToObject<int?>(),
                Closed = @params["Closed"]?.ToObject<bool?>(),
                Curved = @params["Curved"]?.ToObject<bool?>(),
                ColliderMode = @params["ColliderMode"]?.ToObject<bool?>(),

                // 상위 앵커: 오프셋(Vector3)과 비율 모드 필드명 목록
                AnchorOffset = TryReadVector3(@params["AnchorOffset"]),
                RatioParameters = @params["RatioParameters"]?.ToObject<string[]>(),

                PolyhedronType = @params["PolyhedronType"]?.ToString(),
                Material = @params["Material"]?.ToString(),
                Hotspot = @params["Hotspot"]?.ToString(),
            };
        }

        // ── 응답 매핑 ────────────────────────────────────────────────────────

        // Core 의 결과를 CoplayDev MCP 의 응답 객체로 변환.
        internal static object ToResponse(UMXMcpResult result)
        {
            return result.Success
                ? (object)new SuccessResponse(result.Message, result.Data)
                : new ErrorResponse(result.Message);
        }
    }
}
