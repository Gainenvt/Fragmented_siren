using System.Threading.Tasks;
using Unity.AI.MCP.Editor.Helpers;
using Unity.AI.MCP.Editor.ToolRegistry;

namespace Tripolygon.UModelerX.Editor.MCP
{
    public class SceneParams
    {
        [McpDescription("Line-based UModelerX scene DSL script.", Required = true)]
        public string Script { get; set; }
    }

    // Unity.AI.MCP 어댑터. 프로토콜 변환만 담당하고 실제 실행은 UMXSceneOperation 으로 위임.
    [McpTool(
        name: "umx_parametric_shape",
        description: UMXMcpUtility.SceneToolDescription,
        title: "UModelerX: Parametric Shape")]
    public class SceneCommand : IUnityMcpTool<SceneParams>
    {
        public Task<object> ExecuteAsync(SceneParams parameters)
        {
            parameters ??= new SceneParams();
            var result = UMXSceneOperation.Execute(parameters.Script);
            object response = result.Success
                ? Response.Success(result.Message, result.Data)
                : Response.Error(result.Message);
            return Task.FromResult(response);
        }
    }
}
