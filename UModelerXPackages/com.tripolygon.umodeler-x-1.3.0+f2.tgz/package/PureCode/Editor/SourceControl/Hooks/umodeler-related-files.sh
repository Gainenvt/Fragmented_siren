#!/usr/bin/env bash

set -u

projectRoot=${1:-}
if [ -z "$projectRoot" ]; then
    echo "[UModeler] Commit stopped: Unity project root was not provided." >&2
    exit 1
fi

settingsPath="$projectRoot/UserSettings/UModelerSourceControlSettings.json"
if [ ! -f "$settingsPath" ] || ! grep -Eq '"autoIncludeRelatedFiles"[[:space:]]*:[[:space:]]*true' "$settingsPath"; then
    exit 0
fi

manifestPath="$projectRoot/ProjectSettings/UModelerRelatedFiles.manifest"
if [ ! -f "$manifestPath" ]; then
    echo "[UModeler] Commit stopped: related file manifest is missing." >&2
    echo "Open Unity and use Preferences > UModelerX > Source Control > Rebuild Manifest." >&2
    exit 1
fi

manifestHeader=$(sed -n '1{s/\r$//;p;q;}' "$manifestPath")
if [ "$manifestHeader" != "# UModeler related files manifest v2" ]; then
    echo "[UModeler] Commit stopped: related file manifest is invalid or outdated." >&2
    echo "Open Unity and use Preferences > UModelerX > Source Control > Rebuild Manifest." >&2
    exit 1
fi

invalidManifestLine=$(awk -F '\t' '
    NR == 1 { next }
    /^#/ || NF == 0 { next }
    NF != 3 || $1 == "" || $3 == "" || ($2 != "container" && $2 != "reference" && $2 != "alias" && $2 != "generated") {
        print NR
        exit
    }
' "$manifestPath")
if [ -n "$invalidManifestLine" ]; then
    echo "[UModeler] Commit stopped: related file manifest has an invalid row at line $invalidManifestLine." >&2
    echo "Open Unity and rebuild the related file manifest." >&2
    exit 1
fi

repositoryRoot=$(git rev-parse --show-toplevel 2>/dev/null)
if [ -z "$repositoryRoot" ]; then
    echo "[UModeler] Commit stopped: Git repository root could not be resolved." >&2
    exit 1
fi

case "$projectRoot" in
    "$repositoryRoot")
        projectPrefix=""
        ;;
    "$repositoryRoot"/*)
        projectPrefix=${projectRoot#"$repositoryRoot"/}
        ;;
    *)
        echo "[UModeler] Commit stopped: Unity project is outside the Git repository." >&2
        exit 1
        ;;
esac

temporaryRoot=$(mktemp -d 2>/dev/null)
if [ -z "$temporaryRoot" ] || [ ! -d "$temporaryRoot" ]; then
    echo "[UModeler] Commit stopped: temporary directory could not be created." >&2
    exit 1
fi
trap 'rm -rf -- "$temporaryRoot"' EXIT HUP INT TERM

stagedPaths="$temporaryRoot/staged-paths"
resolvedEntries="$temporaryRoot/resolved-entries"
partialPaths="$temporaryRoot/partial-paths"
addedPaths="$temporaryRoot/added-paths"
: > "$stagedPaths"
: > "$resolvedEntries"
: > "$partialPaths"
: > "$addedPaths"

while IFS= read -r -d '' gitPath; do
    if [ -n "$projectPrefix" ]; then
        case "$gitPath" in
            "$projectPrefix"/*)
                projectPath=${gitPath#"$projectPrefix"/}
                ;;
            *)
                continue
                ;;
        esac
    else
        projectPath=$gitPath
    fi

    case "$projectPath" in
        *.meta)
            projectPath=${projectPath%.meta}
            ;;
    esac
    printf '%s\n' "$projectPath" >> "$stagedPaths"
done < <(git diff --cached --name-only -z --diff-filter=ACDMRTUXB)

if [ ! -s "$stagedPaths" ]; then
    exit 0
fi

sort -u -o "$stagedPaths" "$stagedPaths"

unknownContainers=$(awk -F '\t' '
    NR == FNR {
        if ($0 ~ /\.(unity|prefab)$/) {
            staged[$0] = 1
        }
        next
    }
    /^#/ || NF != 3 { next }
    { delete staged[$3] }
    END {
        for (path in staged) {
            print path
        }
    }
' "$stagedPaths" "$manifestPath")
if [ -n "$unknownContainers" ]; then
    echo "[UModeler] Commit stopped: a Scene or Prefab is not recorded in the related file manifest." >&2
    printf '%s\n' "$unknownContainers" | while IFS= read -r path; do
        printf '  %s\n' "$path" >&2
    done
    echo "Open Unity and save the asset, or rebuild the related file manifest." >&2
    exit 1
fi

awk -F '\t' '
    function ensureNode(node) {
        if ((node in parent) == 0) {
            parent[node] = node
        }
    }
    function findRoot(node, root, nextNode) {
        root = node
        while (parent[root] != root) {
            root = parent[root]
        }
        while (parent[node] != node) {
            nextNode = parent[node]
            parent[node] = root
            node = nextNode
        }
        return root
    }
    function joinNodes(leftNode, rightNode, leftRoot, rightRoot) {
        ensureNode(leftNode)
        ensureNode(rightNode)
        leftRoot = findRoot(leftNode)
        rightRoot = findRoot(rightNode)
        if (leftRoot != rightRoot) {
            parent[rightRoot] = leftRoot
        }
    }
    NR == FNR {
        staged[$0] = 1
        next
    }
    /^#/ || NF != 3 { next }
    {
        groupNode = "group:" $1
        pathNode = "path:" $3
        joinNodes(groupNode, pathNode)
        if ($2 == "generated") {
            ownership[$3] = "generated"
        } else if (ownership[$3] == "") {
            ownership[$3] = "general"
        }
    }
    END {
        for (stagedPath in staged) {
            stagedNode = "path:" stagedPath
            if (stagedNode in parent) {
                activeRoot[findRoot(stagedNode)] = 1
            }
        }
        for (currentPath in ownership) {
            currentNode = "path:" currentPath
            if ((currentNode in parent) == 0) {
                continue
            }
            if (activeRoot[findRoot(currentNode)] == 1) {
                print currentPath "\t" ownership[currentPath]
            }
        }
    }
' "$stagedPaths" "$manifestPath" > "$resolvedEntries"

toGitPath()
{
    if [ -n "$projectPrefix" ]; then
        printf '%s/%s' "$projectPrefix" "$1"
    else
        printf '%s' "$1"
    fi
}

hasStagedChanges()
{
    ! git diff --cached --quiet -- "$1"
}

hasUnstagedChanges()
{
    ! git diff --quiet -- "$1"
}

isUntracked()
{
    test -n "$(git ls-files --others --exclude-standard -- "$1")"
}

while IFS=$'\t' read -r projectPath ownership; do
    [ -z "$projectPath" ] && continue
    gitPath=$(toGitPath "$projectPath")
    if [ "$ownership" = "general" ] && hasStagedChanges "$gitPath" && hasUnstagedChanges "$gitPath"; then
        printf '%s\n' "$gitPath" >> "$partialPaths"
    fi
    if [ "$ownership" = "general" ] && hasStagedChanges "$gitPath.meta" && hasUnstagedChanges "$gitPath.meta"; then
        printf '%s\n' "$gitPath.meta" >> "$partialPaths"
    fi
done < "$resolvedEntries"

if [ -s "$partialPaths" ]; then
    echo "[UModeler] Commit stopped." >&2
    echo >&2
    echo "Related file has both staged and unstaged changes:" >&2
    sort -u "$partialPaths" | while IFS= read -r path; do
        printf '  %s\n' "$path" >&2
    done
    echo >&2
    echo "Automatic staging would include changes that were not selected by the user." >&2
    exit 1
fi

stageIfChanged()
{
    candidatePath=$1
    displayPath=$2
    if hasUnstagedChanges "$candidatePath" || isUntracked "$candidatePath"; then
        if git add -A -- "$candidatePath"; then
            printf '%s\n' "$displayPath" >> "$addedPaths"
        else
            echo "[UModeler] Commit stopped: failed to stage '$displayPath'." >&2
            exit 1
        fi
    fi
}

while IFS=$'\t' read -r projectPath ownership; do
    [ -z "$projectPath" ] && continue
    gitPath=$(toGitPath "$projectPath")
    stageIfChanged "$gitPath" "$projectPath"
    stageIfChanged "$gitPath.meta" "$projectPath.meta"
done < "$resolvedEntries"

manifestGitPath=$(toGitPath "ProjectSettings/UModelerRelatedFiles.manifest")
stageIfChanged "$manifestGitPath" "ProjectSettings/UModelerRelatedFiles.manifest"

if [ -s "$addedPaths" ]; then
    sort -u -o "$addedPaths" "$addedPaths"
    addedCount=$(wc -l < "$addedPaths" | tr -d '[:space:]')
    echo "[UModeler] Added $addedCount related files to this commit:"
    while IFS= read -r path; do
        printf '  %s\n' "$path"
    done < "$addedPaths"
fi

exit 0
