#!/usr/bin/env bash

set -euo pipefail

scriptDirectory=$(cd "$(dirname "$0")" && pwd)
runnerPath="$scriptDirectory/../Hooks/umodeler-related-files.sh"
temporaryRoot=$(mktemp -d)
trap 'rm -rf -- "$temporaryRoot"' EXIT HUP INT TERM

repositoryPath="$temporaryRoot/repository"
mkdir -p "$repositoryPath/Assets/캐릭터" "$repositoryPath/Assets/UModelerXData" "$repositoryPath/ProjectSettings" "$repositoryPath/UserSettings" "$repositoryPath/Hooks"
cp "$runnerPath" "$repositoryPath/Hooks/umodeler-related-files.sh"

cd "$repositoryPath"
git init -q
git config user.email "umodeler-test@example.com"
git config user.name "UModeler Hook Test"
git config core.quotepath false

cat > UserSettings/UModelerSourceControlSettings.json <<'JSON'
{
  "autoIncludeRelatedFiles": true
}
JSON

cat > ProjectSettings/UModelerRelatedFiles.manifest <<'MANIFEST'
# UModeler related files manifest v2
group-a	container	Assets/캐릭터/집 모델.prefab
group-a	reference	Assets/Related.prefab
group-a	generated	Assets/UModelerXData/HouseData.asset
group-a	generated	Assets/UModelerXData/HouseMesh.asset
group-b	container	Assets/Other.prefab
group-b	generated	Assets/UModelerXData/OtherData.asset
MANIFEST

printf 'prefab-v1\n' > "Assets/캐릭터/집 모델.prefab"
printf 'related-v1\n' > Assets/Related.prefab
printf 'other-prefab-v1\n' > Assets/Other.prefab
printf 'data-v1\n' > Assets/UModelerXData/HouseData.asset
printf 'mesh-v1\n' > Assets/UModelerXData/HouseMesh.asset
printf 'other-data-v1\n' > Assets/UModelerXData/OtherData.asset
printf 'data-meta-v1\n' > Assets/UModelerXData/HouseData.asset.meta
printf 'mesh-meta-v1\n' > Assets/UModelerXData/HouseMesh.asset.meta
git add -A
git commit -q -m baseline

cat > .git/hooks/pre-commit.umodeler-existing <<'EXISTING_HOOK'
#!/bin/sh
printf 'ran\n' >> existing-hook-ran
EXISTING_HOOK
chmod +x .git/hooks/pre-commit.umodeler-existing

cat > .git/hooks/pre-commit <<'HOOK'
#!/bin/sh
existingHook="$0.umodeler-existing"
"$existingHook" "$@"
existingExitCode=$?
if [ "$existingExitCode" -ne 0 ]; then
    exit "$existingExitCode"
fi
repositoryRoot=$(git rev-parse --show-toplevel)
bash "$repositoryRoot/Hooks/umodeler-related-files.sh" "$repositoryRoot"
HOOK
chmod +x .git/hooks/pre-commit

printf 'prefab-v2\n' >> "Assets/캐릭터/집 모델.prefab"
printf 'data-v2\n' >> Assets/UModelerXData/HouseData.asset
printf 'mesh-meta-v2\n' >> Assets/UModelerXData/HouseMesh.asset.meta
printf 'unrelated-v2\n' >> Assets/UModelerXData/OtherData.asset
printf '# refreshed\n' >> ProjectSettings/UModelerRelatedFiles.manifest
git add -- "Assets/캐릭터/집 모델.prefab"
git commit -q -m modified
modifiedFiles=$(git diff-tree --no-commit-id --name-only -r HEAD)
grep -Fqx 'Assets/캐릭터/집 모델.prefab' <<< "$modifiedFiles"
grep -Fqx 'Assets/UModelerXData/HouseData.asset' <<< "$modifiedFiles"
grep -Fqx 'Assets/UModelerXData/HouseMesh.asset.meta' <<< "$modifiedFiles"
grep -Fqx 'ProjectSettings/UModelerRelatedFiles.manifest' <<< "$modifiedFiles"
if grep -Fqx 'Assets/UModelerXData/OtherData.asset' <<< "$modifiedFiles"; then
    echo "Unrelated manifest group was staged." >&2
    exit 1
fi
git checkout -- Assets/UModelerXData/OtherData.asset
test -s existing-hook-ran

printf 'prefab-v3\n' >> "Assets/캐릭터/집 모델.prefab"
rm Assets/UModelerXData/HouseData.asset Assets/UModelerXData/HouseData.asset.meta
git add -- "Assets/캐릭터/집 모델.prefab"
git commit -q -m deleted
deletedFiles=$(git diff-tree --no-commit-id --name-status -r HEAD)
grep -Fq $'D\tAssets/UModelerXData/HouseData.asset' <<< "$deletedFiles"
grep -Fq $'D\tAssets/UModelerXData/HouseData.asset.meta' <<< "$deletedFiles"

printf 'prefab-v4\n' >> "Assets/캐릭터/집 모델.prefab"
printf 'data-v4\n' > Assets/UModelerXData/HouseData.asset
printf 'data-meta-v4\n' > Assets/UModelerXData/HouseData.asset.meta
git add -- "Assets/캐릭터/집 모델.prefab"
git commit -q -m untracked
untrackedFiles=$(git diff-tree --no-commit-id --name-status -r HEAD)
grep -Fq $'A\tAssets/UModelerXData/HouseData.asset' <<< "$untrackedFiles"
grep -Fq $'A\tAssets/UModelerXData/HouseData.asset.meta' <<< "$untrackedFiles"

printf 'prefab-v5\n' >> "Assets/캐릭터/집 모델.prefab"
printf 'data-v5-staged\n' >> Assets/UModelerXData/HouseData.asset
git add -- "Assets/캐릭터/집 모델.prefab" Assets/UModelerXData/HouseData.asset
printf 'data-v5-unstaged\n' >> Assets/UModelerXData/HouseData.asset
git commit -q -m generated-partial
git show HEAD:Assets/UModelerXData/HouseData.asset | grep -Fq 'data-v5-unstaged'

printf 'prefab-v6\n' >> "Assets/캐릭터/집 모델.prefab"
printf 'related-v2-staged\n' >> Assets/Related.prefab
git add -- "Assets/캐릭터/집 모델.prefab" Assets/Related.prefab
printf 'related-v2-unstaged\n' >> Assets/Related.prefab
if git commit -q -m partial > partial-output 2>&1; then
    echo "Partial-stage test unexpectedly committed." >&2
    exit 1
fi
grep -Fq 'Related file has both staged and unstaged changes' partial-output
git reset -q
git checkout -- "Assets/캐릭터/집 모델.prefab" Assets/Related.prefab
rm partial-output

printf 'new-prefab\n' > Assets/New.prefab
git add -- Assets/New.prefab
if git commit -q -m unknown-container > unknown-output 2>&1; then
    echo "Unknown container test unexpectedly committed." >&2
    exit 1
fi
grep -Fq 'not recorded in the related file manifest' unknown-output
git reset -q -- Assets/New.prefab
rm Assets/New.prefab unknown-output

printf 'prefab-disabled\n' >> "Assets/캐릭터/집 모델.prefab"
printf 'mesh-disabled\n' >> Assets/UModelerXData/HouseMesh.asset
cat > UserSettings/UModelerSourceControlSettings.json <<'JSON'
{
  "autoIncludeRelatedFiles": false
}
JSON
git add -- "Assets/캐릭터/집 모델.prefab"
git commit -q -m disabled
disabledFiles=$(git diff-tree --no-commit-id --name-only -r HEAD)
grep -Fqx 'Assets/캐릭터/집 모델.prefab' <<< "$disabledFiles"
if grep -Fqx 'Assets/UModelerXData/HouseMesh.asset' <<< "$disabledFiles"; then
    echo "Disabled option still staged a related file." >&2
    exit 1
fi
git checkout -- Assets/UModelerXData/HouseMesh.asset UserSettings/UModelerSourceControlSettings.json

echo "UModeler Git hook integration tests passed."
